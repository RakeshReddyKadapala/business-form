const express = require('express');
const app = express()

const api = require('./api');

const cors = require('cors');

app.set('port', (process.env.PORT || 8085))

app.use(express.json())

app.use(express.urlencoded({ extended: false }))

app.use(cors())

app.use('/api', api)
app.use(express.static('static'))


app.use(function (req, res) {
    const err = new Error('Not Found')
    err.status = 404
    res.json({ message: 'jsd' })
})


var mongoose = require('mongoose');


//setting up default mongoose connection
var mongoDB = 'mongodb://127.0.0.1/Business_Form';
mongoose.connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true });

var db = mongoose.connection

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', function () {
    console.log('Connected to MongoDB')

    app.listen(app.get('port'), function () {
        console.log('Api server listening to ' + app.get('port') + '!');
    })
})
