const express = require('express')

const router = express.Router()


require('./routes/main_form')(router)

module.exports = router;