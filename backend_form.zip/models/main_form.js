const mongoose = require('mongoose');


const mainSchema = new mongoose.Schema({

    // Email_Address: String,
    // legal_businessname: String,
    // businessname_oncard: String,
    // businessaddressline1: String,
    // businessaddressline2: String,
    // businessaddress_zipcode: Number,
    // business_ph_no: Number,
    // firstname: String,
    // MI: String,
    // lastname: String,
    // nameoncard: String,
    // homeaddressline1: String,
    // homeaddressline2: String,
    // homeaddresszipcode: Number
    email: String,
    businessname: String,
    cardname: String,
    business_address1: String,
    zip1: Number,
    phone: Number,
    firstname: String,
    lastname: String,
    nameoncard: String,
    homeaddress: String,
    zip: Number,
    business_address2: String,
    MI: String,
    homeaddressline2: String,



})


module.exports = mongoose.model("data", mainSchema)